import * as THREE from "three";

import { FontLoader } from "three/examples/jsm/loaders/FontLoader";
import { TextGeometry } from "three/examples/jsm/geometries/TextGeometry";

export default function initThree(canvas) {
  const colorbg = "#ffffff";

  const textColors = [
    "#FFD166", // warm sunset gold (primary highlight)
    "#FF9F1C", // soft orange glow
    "#E36414", // deep sunset amber
    "#5BC0EB", // glassy sky blue reflection
  ];
  const cubeColors = [
    "#3A86FF", // cool reflective blue (glass contrast)
    "#8338EC", // twilight violet
    "#FF006E", // sunset magenta accent
    "#2EC4B6", // teal glass highlight
  ];

  let textColorIndex = 0;
  let cubeColorIndex = 0;

  function updateColors() {
    textColorIndex = (textColorIndex + 1) % textColors.length;
    cubeColorIndex = (cubeColorIndex + 1) % cubeColors.length;

    if (textMesh) {
      textMesh.material.color.set(textColors[textColorIndex]);
    }

    cube.material.color.set(cubeColors[cubeColorIndex]);
  }

  // Scene
  const scene = new THREE.Scene();

  const textureLoader = new THREE.TextureLoader();

  // === BACKGROUND (COVER IMAGE) ===
  const bgTexture = textureLoader.load("/assets/siting.png", () => {
    resizeBackground();
  });

  bgTexture.colorSpace = THREE.SRGBColorSpace;

  const bgGeometry = new THREE.PlaneGeometry(1, 1);
  const bgMaterial = new THREE.MeshBasicMaterial({
    map: bgTexture,
    depthWrite: false,
  });

  const bgMesh = new THREE.Mesh(bgGeometry, bgMaterial);
  bgMesh.position.z = -10; // stay behind everything
  scene.add(bgMesh);

  function resizeBackground() {
    if (!bgTexture.image) return;

    const aspect = window.innerWidth / window.innerHeight;

    // camera frustum size at bgMesh depth
    const distance = camera.position.z - bgMesh.position.z;
    const height =
      2 * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * distance;
    const width = height * aspect;

    const imageAspect = bgTexture.image.width / bgTexture.image.height;

    if (aspect > imageAspect) {
      bgMesh.scale.set(width, width / imageAspect, 1);
    } else {
      bgMesh.scale.set(height * imageAspect, height, 1);
    }
  }

  // Camera
  const camera = new THREE.PerspectiveCamera(
    60,
    window.innerWidth / window.innerHeight,
    0.1,
    100,
  );
  camera.position.z = 12;

  // Renderer
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
  });
  renderer.setSize(window.innerWidth, window.innerHeight);
  renderer.setPixelRatio(window.devicePixelRatio);

  // === LIGHTS (KEEP IT SIMPLE) ===
  scene.add(new THREE.AmbientLight(0xffffff, 1.2)); // bright

  const dirLight = new THREE.DirectionalLight(0xffffff, 1);
  dirLight.position.set(-5, 5, 5);
  scene.add(dirLight);

  // === TEXT (LEFT) ===
  const loader = new FontLoader();
  let textMesh;

  loader.load(
    "https://threejs.org/examples/fonts/helvetiker_bold.typeface.json",
    (font) => {
      const textGeometry = new TextGeometry("@SUJIT\nSoftware\nDeveloper", {
        font,
        size: 1.5,
        height: 0.5, // 👈 SMALL depth (fix stretch)
      });

      textGeometry.center(); // CENTER TEXT

      const textMaterial = new THREE.MeshStandardMaterial({
        color: textColors[textColorIndex], // PURE WHITE
      });

      // added emmisive
      textMaterial.emissive.set("#331800");
      textMaterial.emissiveIntensity = 0.4;

      textMesh = new THREE.Mesh(textGeometry, textMaterial);
      textMesh.scale.set(1, 1, 0.01);
      textMesh.position.set(-4, 0, 0); // LEFT SIDE
      scene.add(textMesh);

      animate();
    },
  );

  // === CUBE (RIGHT) ===
  const cubeGeometry = new THREE.BoxGeometry(2, 2, 2);
  const cubeMaterial = new THREE.MeshStandardMaterial({
    color: cubeColors[cubeColorIndex],
  });
  const cube = new THREE.Mesh(cubeGeometry, cubeMaterial);
  cube.position.set(4, 0, 0); // RIGHT SIDE
  scene.add(cube);

  // === COLOR UPDATE ===
  function updateColors() {
    textColorIndex = (textColorIndex + 1) % textColors.length;
    cubeColorIndex = (cubeColorIndex + 1) % cubeColors.length;

    if (textMesh) {
      textMesh.material.color.set(textColors[textColorIndex]);
    }
    cube.material.color.set(cubeColors[cubeColorIndex]);
  }

  // Change colors every 1.5s
  setInterval(updateColors, 5000);

  // === ANIMATION ===
  function animate() {
    requestAnimationFrame(animate);

    if (textMesh) {
      textMesh.rotation.y += 0.005; // rotate text
      // textMesh.rotation.x += 0.005;
    }

    cube.rotation.x += 0.01;
    cube.rotation.y += 0.01;

    renderer.render(scene, camera);
  }

  // Resize
  window.addEventListener("resize", () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
    resizeBackground();
  });
}
