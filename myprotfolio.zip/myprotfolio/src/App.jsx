import "./App.css";

import { useEffect, useRef } from "react";

import Menu from "./menu/Menu";
import Services from "./services/Services";
import initThree from "./3ddesign/initthree";

function App() {
  const canvasRef = useRef(null);

  useEffect(() => {
    initThree(canvasRef.current);
  }, []);

  return (
    <>
      <div className="bg-gray-700" id="home">
        <Menu />
        <canvas ref={canvasRef} />
        <Services />
        <footer className="hidden">
          All rights reserved , (c) SUJIT 2026{" "}
        </footer>
      </div>
    </>
  );
}

export default App;
