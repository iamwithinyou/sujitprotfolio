// utils/floatMotion.js
export function getFloatAnimation({
  y = ["0px", "-20px", "20px", "0px"],
  duration = 4,
  type = "loop",
}) {
  return {
    animate: { y: y },
    transition: {
      duration: duration,
      repeat: Infinity,
      repeatType: type,
      ease: "easeInOut",
    },
  };
}
