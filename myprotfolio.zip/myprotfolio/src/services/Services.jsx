import React from "react";
import { getFloatAnimation } from "../utils/motionupdown";
import { motion } from "framer-motion";

export default function Services() {
  const services = [
    {
      title: "Mobile App Development",
      description:
        "Building sleek and responsive mobile applications for iOS and Android with excellent performance and user experience.",
    },
    {
      title: "Web Development (React)",
      description:
        "Creating modern, scalable, and interactive web applications using React, Tailwind CSS, and best practices.",
    },
    {
      title: "Backend Development",
      description:
        "Developing robust backend systems with Spring Boot and Microservices architecture for high scalability and reliability.",
    },
  ];

  return (
    <section id="services" className="py-20 bg-gray-900 text-white">
      <div className="container mx-auto px-6">
        <motion.h2
          className="text-4xl font-bold mb-12 text-center text-yellow-400"
          {...getFloatAnimation({
            y: ["0px", "-5px", "5px", "0px"],
            duration: 5,
          })}
        >
          Our Services
        </motion.h2>

        <div className="grid gap-8 md:grid-cols-3">
          {services.map((service, index) => (
            <motion.div
              key={index}
              className="bg-gray-800 p-6 rounded-xl shadow-lg"
              {...getFloatAnimation({
                y: ["0px", "-20px", "20px", "0px"],
                duration: 5,
              })}
            >
              <h3 className="text-2xl font-semibold mb-4 text-yellow-300">
                {service.title}
              </h3>
              <p className="text-gray-300 mb-6">{service.description}</p>

              <motion.button
                className="bg-yellow-400 text-gray-900 font-semibold px-4 py-2 rounded-lg hover:bg-yellow-500"
                {...getFloatAnimation({
                  y: ["0px", "-2px", "2px", "0px"],
                  duration: 5,
                })}
              >
                Learn More
              </motion.button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
