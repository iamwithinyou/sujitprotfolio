import React from "react";

export default function Menu() {
  return (
    <header className="fixed top-0 left-0 z-20 w-full  ">
      <div
        className="mx-auto flex h-16  items-center justify-between px-8
                      bg-white/10 backdrop-blur-md"
      >
        {/* Logo */}
        <div className="text-xl font-bold tracking-wide text-white">LOGO</div>

        {/* Navigation */}
        <nav className="flex gap-8 text-white font-medium ">
          <a
            href="#home"
            className="relative after:absolute after:-bottom-1 after:left-0 
                       after:h-[2px] after:w-0 after:bg-yellow-400 
                       after:transition-all hover:after:w-full"
          >
            Home
          </a>

          <a
            href="#services"
            className="relative after:absolute after:-bottom-1 after:left-0 
                       after:h-[2px] after:w-0 after:bg-yellow-400 
                       after:transition-all hover:after:w-full"
          >
            Services
          </a>
        </nav>
      </div>
    </header>
  );
}
